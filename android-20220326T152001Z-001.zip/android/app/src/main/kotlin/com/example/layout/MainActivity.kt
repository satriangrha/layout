package com.example.layout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
